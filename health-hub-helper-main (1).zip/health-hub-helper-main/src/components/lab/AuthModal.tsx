import { useState } from "react";
import { X, Mail, Lock, User, Eye, EyeOff, LogIn, UserPlus, Loader2, CheckCircle } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";

interface AuthModalProps {
    onClose: () => void;
}

type Mode = "signin" | "signup";

export function AuthModal({ onClose }: AuthModalProps) {
    const { signIn, signUp } = useAuth();
    const [mode, setMode] = useState<Mode>("signin");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPass, setShowPass] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);

    const validate = () => {
        if (!email.includes("@")) return "Please enter a valid email address.";
        if (password.length < 6) return "Password must be at least 6 characters.";
        if (mode === "signup" && name.trim().length < 2) return "Please enter your full name.";
        return "";
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const err = validate();
        if (err) { setError(err); return; }
        setError("");
        setLoading(true);
        try {
            if (mode === "signin") {
                await signIn(email, password);
            } else {
                await signUp(name.trim(), email, password);
            }
            setSuccess(true);
            setTimeout(onClose, 1200);
        } catch (e: any) {
            setError(e.message ?? "Something went wrong. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />

            {/* Panel */}
            <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden animate-fade-in">
                {/* Top gradient bar */}
                <div className="h-1.5 w-full bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-400" />

                <div className="p-8">
                    {/* Close */}
                    <button
                        onClick={onClose}
                        className="absolute top-5 right-5 w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                    >
                        <X className="h-4 w-4" />
                    </button>

                    {/* Success state */}
                    {success ? (
                        <div className="flex flex-col items-center justify-center py-8 gap-3">
                            <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center">
                                <CheckCircle className="h-8 w-8 text-emerald-500" />
                            </div>
                            <p className="text-lg font-semibold text-slate-800">
                                {mode === "signin" ? "Welcome back!" : "Account created!"}
                            </p>
                            <p className="text-sm text-slate-400">Redirecting you now...</p>
                        </div>
                    ) : (
                        <>
                            {/* Header */}
                            <div className="mb-6">
                                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/25 mb-4">
                                    {mode === "signin" ? <LogIn className="h-6 w-6 text-white" /> : <UserPlus className="h-6 w-6 text-white" />}
                                </div>
                                <h2 className="text-2xl font-bold text-slate-900">
                                    {mode === "signin" ? "Welcome back" : "Create your account"}
                                </h2>
                                <p className="text-sm text-slate-400 mt-1">
                                    {mode === "signin"
                                        ? "Sign in to access your lab reports and history."
                                        : "Join Lab Report AI to save and track your results."}
                                </p>
                            </div>

                            {/* Form */}
                            <form onSubmit={handleSubmit} className="space-y-4">
                                {mode === "signup" && (
                                    <div>
                                        <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Full Name</label>
                                        <div className="relative">
                                            <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                            <input
                                                type="text"
                                                value={name}
                                                onChange={(e) => setName(e.target.value)}
                                                placeholder="John Doe"
                                                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-300 transition-all"
                                            />
                                        </div>
                                    </div>
                                )}

                                <div>
                                    <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Email</label>
                                    <div className="relative">
                                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                        <input
                                            type="email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            placeholder="you@example.com"
                                            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-300 transition-all"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Password</label>
                                    <div className="relative">
                                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                        <input
                                            type={showPass ? "text" : "password"}
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            placeholder="••••••••"
                                            className="w-full pl-10 pr-10 py-3 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-300 transition-all"
                                        />
                                        <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                                            {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                        </button>
                                    </div>
                                </div>

                                {error && (
                                    <div className="text-xs text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">
                                        {error}
                                    </div>
                                )}

                                <button
                                    type="submit"
                                    disabled={loading}
                                    className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold text-sm hover:from-blue-600 hover:to-cyan-600 disabled:opacity-60 transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2"
                                >
                                    {loading ? (
                                        <><Loader2 className="h-4 w-4 animate-spin" /> {mode === "signin" ? "Signing in..." : "Creating account..."}</>
                                    ) : (
                                        mode === "signin" ? "Sign In" : "Create Account"
                                    )}
                                </button>
                            </form>

                            {/* Toggle mode */}
                            <p className="text-center text-sm text-slate-500 mt-5">
                                {mode === "signin" ? "Don't have an account?" : "Already have an account?"}{" "}
                                <button
                                    onClick={() => { setMode(mode === "signin" ? "signup" : "signin"); setError(""); }}
                                    className="font-semibold text-blue-600 hover:text-blue-700 transition-colors"
                                >
                                    {mode === "signin" ? "Sign up" : "Sign in"}
                                </button>
                            </p>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}
